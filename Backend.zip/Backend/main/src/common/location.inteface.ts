export interface Location {
  readonly type: 'Point',
  readonly coordinates: [number, number];
}