export const seeds = [
  {
    "name": "iCombo 1 Big",
    "desc": "1 Corn + 1 Drink (PEPSI/7UP/MIRINDA CAM/MIRINDA SARSI)",
    "img": "https://s3img.vcdn.vn/123phim/2019/11/028da9b5ccfd9bfedca34b2c1614f324.png",
    "price": 62000
  },
  {
    "name": "iCombo 2",
    "desc": "1 Corn + 2 Drinks (PEPSI/7UP/MIRINDA CAM/MIRINDA SARSI)",
    "img": "https://s3img.vcdn.vn/123phim/2018/09/12c175c92d4c9fc879afb044299abb74.jpg",
    "price": 72000
  },
  {
    "name": "iCombo Family 1",
    "desc": "1 Corn + 3 Drinks 22 Oz(PEPSI/7UP/MIRINDA CAM/MIRINDA SARSI/LIPTON/Water) + 1 SNACK",
    "img": "https://s3img.vcdn.vn/123phim/2018/09/12c175c92d4c9fc879afb044299abb74.jpg",
    "price": 107000
  },
  {
    "name": "iCombo Family 2",
    "desc": "2 Corns + 4 Drinks (PEPSI/7UP/MIRINDA CAM/MIRINDA SARSI/LIPTON) + 1 SNACK",
    "img": "https://s3img.vcdn.vn/123phim/2018/09/12c175c92d4c9fc879afb044299abb74.jpg",
    "price": 152000
  },
  {
    "name": "iWe Bare Bears Combo 1",
    "desc": "1 Corn + 1 (PEPSI/7UP/MIRINDA CAM/MIRINDA SARSI)",
    "img": "https://s3img.vcdn.vn/123phim/2019/11/028da9b5ccfd9bfedca34b2c1614f324.png",
    "price": 154000
  }
];